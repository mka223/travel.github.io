<?php

$con = mysqli_connect("localhost","root","","tms");

if(isset($_POST['submit']))
{
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
	$username = $_POST['username'];
	$email = $_POST['email'];
	$phone = $_POST['phone'];
	$address= $_POST['address'];
    $password = $_POST['password'];
    
    $querry = "INSERT INTO user (fname,lname,username,email,phone,address,password,) VALUES ('$fname','$lname','$username','$email','$phone','$address','$password')";
    $querry_run = mysqli_query($con, $querry);

}